 export const MenuItem=[
    {
        title: "Home",
        url:"/",
        cName: 'nav-links',
        expand:[
            "salom",
            "salom",
            "salom",
        ]
    }, {
        title: "Books",
        url:"/schools",
        cName: 'nav-link',
        expand:[
            "salom",
            "salom",
            "salom",
        ]
    }, {
        title: "Skills",
        url:"/skills",
        cName: 'nav-links',
    }, {
        title: "Grammar",
        url:"/grammar",
        cName: 'nav-links'
    }, {
        title: "Vocabulary",
        url:"/vocabulary",
        cName: 'nav-links'
    }, {
        title: "Business English",
        url:"/business",
        cName: 'nav-links'
    }, {
        title: "General English",
        url:"/general",
        cName: 'nav-links'
    }, {
        title: "IELTS",
        url:"/ielts",
        cName: 'nav-links'
    }, {
        title: "Community",
        url:"/community",
        cName: 'nav-links-mobile'
    }

]