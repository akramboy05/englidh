import React from "react";
import "./Banner.css";
import bannerImg1 from "../../images/banner-box/banner-box.jpg"
import bannerImg2 from "../../images/banner-box/banner-box.jpeg"
import bannerImg3 from "../../images/banner-box/banner-box2.jpeg"



export default function App() {
  return (
    <>
      <div className="Banner">
        
      </div>  
    </>
  );
}
