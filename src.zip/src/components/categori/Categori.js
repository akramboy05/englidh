import React from 'react'
import "./categori.css"


function Categori() {
    return (
        <div className='categori'>
          
        </div>
    )
}

export default Categori