import React from 'react'
import HomeProduct from '../homeProduct/HomeProduct'
import "./ProductWrapper.css"


function ProductWrapper() {
  return (
    <div className='product_wrapper'>
    </div>
  )
}

export default ProductWrapper