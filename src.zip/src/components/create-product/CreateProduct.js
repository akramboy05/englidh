import React from 'react'
import "./CreateProduct.css"

function CreateProduct() {
  return (
    <div>CreateProduct</div>
  )
}

export default CreateProduct