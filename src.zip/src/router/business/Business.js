import React from 'react'
import "./Business.css"

const Business = () => {
  return (
    <div>
      <h1>Business English</h1>
    </div>
  )
}

export default Business