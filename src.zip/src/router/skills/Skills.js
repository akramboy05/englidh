import React from 'react'
import "./Skills.css"

const Skills = () => {
  return (
    <div>
      <h1>Skills Page</h1>
    </div>
  )
}

export default Skills