import React from 'react'
import "./Community.css"

const Community = () => {
  return (
    <div>
      <h1>Community Page</h1>
    </div>
  )
}

export default Community