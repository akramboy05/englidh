import React from 'react'

const AudioBook = () => {
  return (
    <div>AudioBook</div>
  )
}

export default AudioBook