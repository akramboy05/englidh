import React from 'react'
import "./Books.css"

const Books = () => {
  return (
    <div>
        <h1>Books </h1>
    </div>
  )
}

export default Books