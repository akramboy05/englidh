import React from 'react'
import "./Login.css"

const Login = () => {
  return (
    <div>
        <span className='login_first_span'><div></div> <h1>Log in</h1></span>
        
        <div className="login_container">

        </div>
    </div>
  )
}

export default Login