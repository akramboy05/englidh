import React from 'react'
import "./Vocabulary.css"

const Vocabulary = () => {
  return (
    <div>Vocabulary</div>
  )
}

export default Vocabulary