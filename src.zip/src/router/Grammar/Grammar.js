import React from 'react'
import "./Grammar.css"

const Grammar = () => {
  return (
    <div>
      <h1>Grammar Page</h1>
    </div>
  )
}

export default Grammar