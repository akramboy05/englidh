import React from 'react'
import "./General.css"

const General = () => {
  return (
    <div>
      <h1>General page</h1>
    </div>
  )
}

export default General