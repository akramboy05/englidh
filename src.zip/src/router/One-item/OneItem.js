import React from 'react'

const OneItem = () => {
  return (
    <div>
        
    </div>
  )
}

export default OneItem