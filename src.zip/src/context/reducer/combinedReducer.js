import { combineReducers } from "redux";

const combinedReduser = combineReducers({
})

export default combinedReduser