export const HomeBooks = [
    {
        id: 0,
        img:"https://www.powells.com/portals/0/Images/9781635422658.jpg",
        title:"Astonishing the Gods",
        owner:"Ben Okri"
    },
    {
        id: 1,
        img:"https://www.powells.com/portals/0/Images/fives/9781621067061.jpg",
        title:"How to Resist Amazon and Why",
        owner:"Tove H."
    },
    {
        id: 2,
        img:"https://www.powells.com/portals/0/Images/fives/9780399563645.jpg",
        title:"The Book of Form and Emptiness",
        owner:"Jennifer H."
    },
    {
        id: 3,
        img:"https://www.powells.com/portals/0/Images/fives/9780819579751.jpg",
        title:"Occasional Views, Vol",
        owner:"Fletcher O."
    },
    {
        id: 4,
        img:"https://www.powells.com/portals/0/Images/fives/9780143129707.jpg",
        title:"American Predator ",
        owner:"Emily C."
    },
    {
        id: 5,
        img:"https://www.powells.com/portals/0/Images/fives/9780358410768.jpg",
        title:"Tuesday Mooney Talks to Ghosts",
        owner:"Summer R."
    },
    {
        id: 6,
        img:"https://www.powells.com/portals/0/Images/fives/9780525538899.jpg",
        title:"Real Life",
        owner:"Michelle C."
    },
    {
        id: 7,
        img:"https://www.powells.com/portals/0/Images/9781324020240.jpg",
        title:"The Man Who Ate Too Much",
        owner:"John Birdsall"
    },
    {
        id: 8,
        img:"https://www.powells.com/portals/0/Images/9780062947369.jpg",
        title:"Read Dangerously",
        owner:"Azar Nafisi"
    },
    {
        id: 9,
        img:"https://www.powells.com/portals/0/Images/9780393867732.jpg",
        title:"Free",
        owner:"Lea Ypi"
    },
    {
        id: 10,
        img:"https://www.powells.com/portals/0/Images/9781643750941.jpg",
        title:"Perpetual West ",
        owner:"Mesha Maren"
    },
    {
        id: 11,
        img:"https://www.powells.com/portals/0/Images/9780062977403.jpg",
        title:"South to America",
        owner:"Imani Perry"
    }
]